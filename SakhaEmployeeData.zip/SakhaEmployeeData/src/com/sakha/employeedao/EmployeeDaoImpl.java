package com.sakha.employeedao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;

import com.sakha.model.Employee;
import com.sun.corba.se.spi.orbutil.fsm.Guard.Result;
//import com.sun.corba.se.impl.ior.GenericTaggedComponent;


public class EmployeeDaoImpl implements EmployeeDao{
	Connection con;
	//EmployeeDao dao;
	public Connection getConnection() throws Exception
	{
		con= DriverManager.getConnection("jdbc:mysql://localhost/sakhadb","root","root");
		return con;
	}
	/*public String generatedId(String empname)throws Exception {
		con=getConnection();
		PreparedStatement ps= con.prepareStatement("select empid from emp  where empname="+empname);
		ResultSet rs= ps.executeQuery();
		String id=null;
		while(rs.next())
		{
			id=rs.getString(1);
		}
		return id;*/


	@Override
	public boolean addEmployee(Employee e) throws Exception {
		// TODO Auto-generated method stub
		 con= getConnection(); 
		 PreparedStatement ps=null;
		 ps= con.prepareStatement("select * from emp where name="+"'"+e.getName()+"'");
		 ResultSet r= ps.executeQuery();
		 if(r.next())
		 {
			 return false;
		 }
		 ps= con.prepareStatement("insert into emp values(?,?,?,?)");
		 ps.setString(1,e.getEmpid());
		 
		 ps.setString(2, e.getName());
		 LocalDate dob= e.getDOB();
		 ps.setDate(3, new java.sql.Date(dob.getYear()-1900,dob.getMonthValue()-1,dob.getDayOfMonth()));
		 ps.setFloat(4, e.getSalary());
		 int rs=ps.executeUpdate();
		 if(rs>0)
		{
			return true;
		}
		 return false;
	}


	@Override
	public String generatedId(String empname) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean deleteEmployee(String empid) throws Exception {
		// TODO Auto-generated method stub
		con= getConnection();
		PreparedStatement ps= null;
		ps= con.prepareStatement("delete from emp where empid='"+empid+"'");
		int r= ps.executeUpdate();
		if(r>0) {
			return  true;
		}
		return false;
	
}
	public Employee getEmp(String empid) throws Exception
	{
		con=getConnection();
		PreparedStatement ps= null;
		Employee e= new Employee();
		ps= con.prepareStatement("select * from emp where empid='"+empid+"'");
		ResultSet rs= ps.executeQuery();
		if(rs.next())
		{
			e.setEmpid(rs.getString(1));
			e.setName(rs.getString(2));
			Date dob1 = rs.getDate(3);
			LocalDate.of(dob1.getYear(), dob1.getMonth(), dob1.getDate());
			e.setDOB(((java.sql.Date) dob1).toLocalDate());
			//ps.setDate(3, new java.sql.Date(dob1.getYear()-1900,dob1.getMonthValue()-1,dob1.getDayOfMonth()));
			//e.setDOB(dob1.toLocalDate());
			e.setSalary(rs.getFloat(4));
			return e;
		}
		return null;
	}
	public List<Employee>getAllEmployee() throws Exception
	{
		con = getConnection();
		PreparedStatement ps= null;
		List<Employee>emp = new ArrayList<>();
		Employee e ;
		ps=con.prepareStatement("select * from emp ");
		ResultSet rs =ps.executeQuery();
		while(rs.next())
		{
			e=new Employee();
			e.setEmpid(rs.getString(1));
			e.setName(rs.getString(2));
			Date dob1 = rs.getDate(3);
			LocalDate.of(dob1.getYear(), dob1.getMonth(), dob1.getDate());
			e.setDOB(((java.sql.Date) dob1).toLocalDate());
			//ps.setDate(3, new java.sql.Date(dob1.getYear()-1900,dob1.getMonthValue()-1,dob1.getDayOfMonth()));
			//e.setDOB(dob1.toLocalDate());
			e.setSalary(rs.getFloat(4));
			emp.add(e);
		}
		return emp;
	}
	public boolean updateEmployee(String empid, float salary)throws Exception
	{
		con=getConnection();
		PreparedStatement ps= null;
		int rs= 0;
		if(empid!= null && salary >0)
		{
			ps=con.prepareStatement("update emp set salary="+salary+" where empid ='"+empid+"'");
			rs= ps.executeUpdate();
		}
		if(rs>0)
		{
			return true;
		}
		return false;
	}
} 
package com.sakha.service;

import com.sakha.employeedao.EmployeeDao;
import com.sakha.employeedao.EmployeeDaoImpl;

public class UpdateEmployeeService {
	EmployeeDao dao= new EmployeeDaoImpl();
	public boolean updateEmployee(String empid,float salary) throws Exception
	{
		return dao.updateEmployee(empid,salary);
	}
}

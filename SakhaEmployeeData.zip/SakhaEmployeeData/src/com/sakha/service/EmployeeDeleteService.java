package com.sakha.service;

import com.sakha.employeedao.EmployeeDao;
import com.sakha.employeedao.EmployeeDaoImpl;

public class EmployeeDeleteService {
	EmployeeDao dao= new EmployeeDaoImpl();
			
	public boolean delete(String empid) throws Exception
	{
		return dao.deleteEmployee(empid);
		
	}

}

package com.sakha.service;

import java.sql.Connection;
import java.util.Random;

import com.sakha.employeedao.EmployeeDao;
import com.sakha.employeedao.EmployeeDaoImpl;
import com.sakha.model.Employee;

public class AddEmployeeService {
	EmployeeDao dao= new EmployeeDaoImpl();
	public boolean addEmployee(Employee e) throws Exception
	{
	
	return dao.addEmployee(e);	
	}
	public String generatedId(String empName) throws Exception {
		String nameChar=empName.substring(0,2).toUpperCase();
		Random rand= new Random();
		int dgt=(int) (rand.nextDouble()*10000);
		return nameChar+dgt;
	}
}
